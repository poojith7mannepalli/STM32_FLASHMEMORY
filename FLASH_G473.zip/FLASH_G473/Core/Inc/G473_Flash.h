
#ifndef FLASH_OPERATIONS_H
#define FLASH_OPERATIONS_H
#include "stm32g4xx_hal.h"
#include "main.h"
#include "stdlib.h"
#include "stdint.h"

extern uint32_t UL_page;
extern uint32_t UL_bank;

typedef struct {
    uint32_t UL_bankNumber;
    uint32_t UL_pageNumber;
} st_FlashLocation;

st_FlashLocation BSP_GetBankAndPageNumber(uint32_t UL_address);
void BSP_WriteFlash(uint32_t UL_address, uint32_t* UL_data, uint32_t UL_size);
void BSP_readInternalFlash(uint32_t UL_address ,uint32_t UL_data[4]);

#endif /* FLASH_OPERATIONS_H */


